import greenfoot.*;

public class clevel15 extends Actor
{
    private GreenfootImage clevel15;
    public clevel15(){
        clevel15 = new GreenfootImage("clevel15.png");
        clevel15.scale(100, 75);
        setImage(clevel15);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level15()); 
        }
    }
}
