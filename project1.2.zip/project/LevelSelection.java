import greenfoot.*;

/**
 * Экран выбора уровня.
 * Располагает 20 иконок уровней в сетке 5x4.
 */
public class LevelSelection extends World {

    // Параметры сетки
    private static final int COLUMNS = 5;      // колонок
    private static final int ROWS = 4;         // рядов
    private static final int ICON_WIDTH = 80;  // ширина ячейки
    private static final int ICON_HEIGHT = 80; // высота ячейки
    private static final int START_X = 80;     // отступ слева
    private static final int START_Y = 60;     // отступ сверху

    public LevelSelection() {    
        super(600, 400, 1); 
        setBackground("background.png");

        // Кнопка "Назад в меню"
        addObject(new backtomain(), 100, 350);

        // Массив иконок — для удобства
        Actor[] levelIcons = {
            new clevel1(),
            new clevel2(),
            new clevel3(),
            new clevel4(),
            new clevel5(),
            new clevel6(),
            new clevel7(),
            new clevel8(),
            new clevel9(),
            new clevel10(),
            new clevel11(),
            new clevel12(),
            new clevel13(),
            new clevel14(),
            new clevel15(),
            new clevel16(),
            new clevel17(),
            new clevel18(),
            new clevel19(),
            new clevel20()
        };

        // Размещаем иконки в сетке
        for (int i = 0; i < levelIcons.length; i++) {
            int row = i / COLUMNS;           // номер ряда (0, 1, 2, 3)
            int col = i % COLUMNS;           // номер колонки (0–4)
            int x = START_X + col * ICON_WIDTH;
            int y = START_Y + row * ICON_HEIGHT;
            addObject(levelIcons[i], x, y);
        }
    }
}