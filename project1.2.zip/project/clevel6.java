import greenfoot.*;

public class clevel6 extends Actor
{
    private GreenfootImage clevel6;
    public clevel6(){
        clevel6 = new GreenfootImage("clevel6.png");
        clevel6.scale(100, 75);
        setImage(clevel6);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level6()); 
        }
    }
}
