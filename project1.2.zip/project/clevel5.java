import greenfoot.*;

public class clevel5 extends Actor
{
    private GreenfootImage clevel5;
    public clevel5(){
        clevel5 = new GreenfootImage("clevel5.png");
        clevel5.scale(100, 75);
        setImage(clevel5);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level5()); 
        }
    }
}
