import greenfoot.*;

public class clevel12 extends Actor
{
    private GreenfootImage clevel12;
    public clevel12(){
        clevel12 = new GreenfootImage("clevel12.png");
        clevel12.scale(100, 75);
        setImage(clevel12);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level12()); 
        }
    }
}
