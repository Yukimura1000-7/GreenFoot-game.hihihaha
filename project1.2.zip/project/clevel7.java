import greenfoot.*;

public class clevel7 extends Actor
{
    private GreenfootImage clevel7;
    public clevel7(){
        clevel7 = new GreenfootImage("clevel7.png");
        clevel7.scale(100, 75);
        setImage(clevel7);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level7()); 
        }
    }
}
