import greenfoot.*;

public class Level2 extends World {
    public Level2() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.GRAY);
        bg.fill();
        setBackground(bg);
        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new pressurePlate(), 150, 550);
        addObject(new key(), 500, 300);
        addObject(new door(3), 700, 300);
        addObject(new barrel(), 200, 400);
        addObject(new torch(), 600, 550);
        
        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level2());
        }
        
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
            addObject(new wall(), x, 20);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}