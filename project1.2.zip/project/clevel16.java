import greenfoot.*;

public class clevel16 extends Actor
{
    private GreenfootImage clevel16;
    public clevel16(){
        clevel16 = new GreenfootImage("clevel16.png");
        clevel16.scale(100, 75);
        setImage(clevel16);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level16()); 
        }
    }
}
