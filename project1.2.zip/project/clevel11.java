import greenfoot.*;

public class clevel11 extends Actor
{
    private GreenfootImage clevel11;
    public clevel11(){
        clevel11 = new GreenfootImage("clevel11.png");
        clevel11.scale(100, 75);
        setImage(clevel11);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level11()); 
        }
    }
}
