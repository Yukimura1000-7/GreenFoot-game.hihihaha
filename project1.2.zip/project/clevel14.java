import greenfoot.*;

public class clevel14 extends Actor
{
    private GreenfootImage clevel14;
    public clevel14(){
        clevel14 = new GreenfootImage("clevel14.png");
        clevel14.scale(100, 75);
        setImage(clevel14);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level14()); 
        }
    }
}
