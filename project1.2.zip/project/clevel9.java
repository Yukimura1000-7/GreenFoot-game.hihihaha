import greenfoot.*;

public class clevel9 extends Actor
{
    private GreenfootImage clevel9;
    public clevel9(){
        clevel9 = new GreenfootImage("clevel9.png");
        clevel9.scale(100, 75);
        setImage(clevel9);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level9()); 
        }
    }
}
