import greenfoot.*;

public class clevel1 extends Actor {
    public clevel1() {
        GreenfootImage img = new GreenfootImage("clevel1.png");
        img.scale(80, 80);
        setImage(img);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level1());
        }
    }
}