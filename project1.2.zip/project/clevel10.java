import greenfoot.*;

public class clevel10 extends Actor
{
    private GreenfootImage clevel10;
    public clevel10(){
        clevel10 = new GreenfootImage("clevel10.png");
        clevel10.scale(100, 75);
        setImage(clevel10);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level10()); 
        }
    }
}
