import greenfoot.*;

public class Level7 extends World {
    public Level7() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.ORANGE);
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new pressurePlate(), 200, 400);
        addObject(new pressurePlate(), 300, 400);
        addObject(new pressurePlate(), 400, 400);
        addObject(new key(), 500, 300);
        addObject(new door(8), 700, 300);

        addObject(new barrel(), 150, 450);
        addObject(new bush(), 600, 200);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level7());
        }
        
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}