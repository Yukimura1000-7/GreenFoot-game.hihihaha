import greenfoot.*;

public class clevel17 extends Actor
{
    private GreenfootImage clevel17;
    public clevel17(){
        clevel17 = new GreenfootImage("clevel17.png");
        clevel17.scale(100, 75);
        setImage(clevel17);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level17()); 
        }
    }
}
