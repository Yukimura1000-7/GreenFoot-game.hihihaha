import greenfoot.*;

public class pressurePlate extends Actor {
    private boolean isActive = false;

    public pressurePlate() {
        setImage("plate.png"); 
    }

    public void act() {
        checkActivation();
    }

    private void checkActivation() {
        boolean pressed = 
            isTouching(hero.class) || 
            isTouching(box.class) || 
            isTouching(mentor.class);
        
        if (pressed != isActive) {
            isActive = pressed;
            String msg = isActive ? "Плита активирована!" : "Плита деактивирована.";
            getWorld().addObject(new GameMessage(msg), 400, 50);
        }
    }

    public boolean isActive() {
        return isActive;
    }
}