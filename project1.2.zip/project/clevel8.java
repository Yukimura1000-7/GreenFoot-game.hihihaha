import greenfoot.*;

public class clevel8 extends Actor
{
    private GreenfootImage clevel8;
    public clevel8(){
        clevel8 = new GreenfootImage("clevel8.png");
        clevel8.scale(100, 75);
        setImage(clevel8);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level8()); 
        }
    }
}
