import greenfoot.*;

public class clevel19 extends Actor
{
    private GreenfootImage clevel19;
    public clevel19(){
        clevel19 = new GreenfootImage("clevel19.png");
        clevel19.scale(100, 75);
        setImage(clevel19);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level19()); 
        }
    }
}
