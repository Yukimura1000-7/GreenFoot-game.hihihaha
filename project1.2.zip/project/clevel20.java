import greenfoot.*;

public class clevel20 extends Actor
{
    private GreenfootImage clevel20;
    public clevel20(){
        clevel20 = new GreenfootImage("clevel20.png");
        clevel20.scale(100, 75);
        setImage(clevel20);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level20()); 
        }
    }
}
