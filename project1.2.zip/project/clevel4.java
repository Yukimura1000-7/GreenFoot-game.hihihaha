import greenfoot.*;

public class clevel4 extends Actor
{
    private GreenfootImage clevel4;
    public clevel4(){
        clevel4 = new GreenfootImage("clevel4.png");
        clevel4.scale(100, 75);
        setImage(clevel4);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level4()); 
        }
    }
}
