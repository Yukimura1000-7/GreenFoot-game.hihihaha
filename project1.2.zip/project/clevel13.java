import greenfoot.*;

public class clevel13 extends Actor
{
    private GreenfootImage clevel13;
    public clevel13(){
        clevel13 = new GreenfootImage("clevel13.png");
        clevel13.scale(100, 75);
        setImage(clevel13);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level13()); 
        }
    }
}
