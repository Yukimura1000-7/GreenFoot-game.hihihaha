import greenfoot.*;

public class clevel18 extends Actor
{
    private GreenfootImage clevel18;
    public clevel18(){
        clevel18 = new GreenfootImage("clevel18.png");
        clevel18.scale(100, 75);
        setImage(clevel18);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level18()); 
        }
    }
}
