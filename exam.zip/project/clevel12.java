import greenfoot.*;

public class clevel12 extends Actor
{
    private GreenfootImage clevel12;
    public clevel12(){
        clevel12 = new GreenfootImage("clevel12.png");
        setImage(clevel12);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
