import greenfoot.*;

public class Boundary extends Actor {
    public Boundary() {
        setImage(new GreenfootImage(1, 1));
    }
}