import greenfoot.*;

public class lever extends Actor {
    private boolean isActive = false;

    public lever() {
        setImage("lever_off.png"); // 24x24
    }

    public void act() {
        checkActivation();
    }

    private void checkActivation() {
        hero player = (hero) getOneObjectAtOffset(0, 0, hero.class);
        if (player != null && Greenfoot.isKeyDown("e")) {
            isActive = !isActive;
            updateImage();
            String msg = isActive ? "Рычаг включён!" : "Рычаг выключен.";
            getWorld().addObject(new GameMessage(msg), 400, 50);
            try { Thread.sleep(200); } catch (Exception e) {}
        }
    }

    private void updateImage() {
        if (isActive) {
            setImage("lever_on.png");
        } else {
            setImage("lever_off.png");
        }
    }

    public boolean isActive() {
        return isActive;
    }
}