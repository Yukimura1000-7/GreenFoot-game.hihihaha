import greenfoot.*;

public class clevel18 extends Actor
{
    private GreenfootImage clevel18;
    public clevel18(){
        clevel18 = new GreenfootImage("clevel18.png");
        setImage(clevel18);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
