import greenfoot.*;

public class Level12 extends World {
    public Level12() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(0, 80, 120));
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new timeCrystal(), 300, 400);
        addObject(new box(), 400, 500);
        //addObject(new pressurePlate(), 400, 550);
        addObject(new key(), 500, 300);
        addObject(new door(13), 700, 300);
        addObject(new torch(), 50, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level12());
        }
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}