import greenfoot.*;

public class clevel10 extends Actor
{
    private GreenfootImage clevel10;
    public clevel10(){
        clevel10 = new GreenfootImage("clevel10.png");
        setImage(clevel10);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
