import greenfoot.*;

public class door extends Actor {
    private int nextLevel;

    public door(int nextLevel) {
        this.nextLevel = nextLevel;
        updateImage();
    }

    public void act() {
        if (GameState.hasKey && isTouching(hero.class)) {
            GameState.hasKey = false;
            GameState.completeLevel(nextLevel - 1);

            World nextWorld = null;
            switch (nextLevel) {
                case 1: nextWorld = new Level1(); break;
                case 2: nextWorld = new main_menu(); break;
                case 3: nextWorld = new Level3(); break;
                case 4: nextWorld = new Level4(); break;
                case 5: nextWorld = new Level5(); break;
                case 6: nextWorld = new Level6(); break;
                case 7: nextWorld = new Level7(); break;
                case 8: nextWorld = new Level8(); break;
                case 9: nextWorld = new Level9(); break;
                case 10: nextWorld = new Level10(); break;
                case 11: nextWorld = new Level11(); break;
                case 12: nextWorld = new Level12(); break;
                case 13: nextWorld = new Level13(); break;
                case 14: nextWorld = new Level14(); break;
                case 15: nextWorld = new Level15(); break;
                case 16: nextWorld = new Level16(); break;
                case 17: nextWorld = new Level17(); break;
                case 18: nextWorld = new Level18(); break;
                case 19: nextWorld = new Level19(); break;
                case 20: nextWorld = new Level20(); break;
                default: nextWorld = new VictoryScreen(); break;
            }
            Greenfoot.setWorld(nextWorld);
        }
        updateImage();
    }

    private void updateImage() {
        if (GameState.hasKey) {
            setImage("door_open.png"); 
        } else {
            setImage("door_closed.png"); 
        }
    }
}