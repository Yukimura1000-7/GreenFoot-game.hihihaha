import greenfoot.*;

public class mirror extends Actor {
    public mirror() {
        setImage("mirror.png"); 
    }
}