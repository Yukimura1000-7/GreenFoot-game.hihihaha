import greenfoot.*;

public class hero extends Actor {
    private final int speed = 2;

    public hero() {
        setImage("hero.png");
    }

    public void act() {
        handleMovement();
        handleInteraction();
    }

    // В hero.java
private void handleMovement() {
    int prevX = getX();
    int prevY = getY();

    if (Greenfoot.isKeyDown("left")) setLocation(getX() - 1, getY());
    if (Greenfoot.isKeyDown("right")) setLocation(getX() + 1, getY());
    if (Greenfoot.isKeyDown("up")) setLocation(getX(), getY() - 1);
    if (Greenfoot.isKeyDown("down")) setLocation(getX(), getY() + 1);

    if (isTouching(InvisibleWall.class) || 
        isTouching(barrel.class) || 
        isTouching(bush.class) || 
        isTouching(torch.class) ||
        isTouching(wall.class) ||
        isTouching(wall2.class)){
        setLocation(prevX, prevY);
    }
}

    private void handleInteraction() {
        if (isTouching(key.class)) {
            GameState.hasKey = true;
            removeTouching(key.class);
            getWorld().addObject(new GameMessage("Ключ подобран!"), 400, 50);
        }
        pushBox();
    }

    private void pushBox() {
        for (Object obj : getObjectsInRange(20, box.class)) {
            box b = (box) obj;
            int dx = getX() - b.getX();
            int dy = getY() - b.getY();

            if (Math.abs(dx) > Math.abs(dy)) {
                if (dx > 0 && Greenfoot.isKeyDown("left")) b.setLocation(b.getX() - speed, b.getY());
                else if (dx < 0 && Greenfoot.isKeyDown("right")) b.setLocation(b.getX() + speed, b.getY());
            } else {
                if (dy > 0 && Greenfoot.isKeyDown("up")) b.setLocation(b.getX(), b.getY() - speed);
                else if (dy < 0 && Greenfoot.isKeyDown("down")) b.setLocation(b.getX(), b.getY() + speed);
            }
        }
    }
}