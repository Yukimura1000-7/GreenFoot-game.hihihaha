import greenfoot.*;

public class torch extends Actor {
    public torch() {
        setImage("torch.png"); 
    }
}