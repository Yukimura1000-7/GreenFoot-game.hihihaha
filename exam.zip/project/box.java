import greenfoot.*;

public class box extends Actor {
    public box() {
        setImage("box.png"); 
    }
}