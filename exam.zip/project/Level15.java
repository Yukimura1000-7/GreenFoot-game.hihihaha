import greenfoot.*;

public class Level15 extends World {
    public Level15() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(0, 140, 200));
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new mirror(), 300, 400);
        addObject(new timeCrystal(), 400, 400);
        addObject(new key(), 500, 300);
        addObject(new door(16), 700, 300);

        addObject(new torch(), 50, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level15());
        }
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}