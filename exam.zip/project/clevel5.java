import greenfoot.*;

public class clevel5 extends Actor
{
    private GreenfootImage clevel5;
    public clevel5(){
        clevel5 = new GreenfootImage("clevel5.png");
        setImage(clevel5);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
