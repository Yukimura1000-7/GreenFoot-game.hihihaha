import greenfoot.*;

public class InvisibleWall extends Actor {
    public InvisibleWall() {
        setImage("invisibleWall.png"); 
    }
}