import greenfoot.*;

public class clevel19 extends Actor
{
    private GreenfootImage clevel19;
    public clevel19(){
        clevel19 = new GreenfootImage("clevel19.png");
        setImage(clevel19);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
