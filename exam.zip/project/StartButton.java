import greenfoot.*;

public class StartButton extends Actor {
    private GreenfootImage normalImage;

    public StartButton() {
        normalImage = new GreenfootImage("startbutton.png");
        setImage(normalImage);
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new LevelSelection()); 
        }
    }
}