import greenfoot.*;

public class clevel20 extends Actor
{
    private GreenfootImage clevel20;
    public clevel20(){
        clevel20 = new GreenfootImage("clevel20.png");
        setImage(clevel20);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
