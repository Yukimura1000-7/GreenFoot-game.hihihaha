// Хранит прогресс между уровнями: ключи, секреты, пройденные уровни
public class GameState {
    // Флаг: есть ли у игрока ключ (сбрасывается при переходе на новый уровень)
    public static boolean hasKey = false;
    
    // Массив: true, если уровень пройден (Level1 = индекс 0)
    public static boolean[] levelsCompleted = new boolean[20];
    
    // Счётчик собранных секретных артефактов
    public static int collectedArtifacts = 0;

    // Сброс всего прогресса (например, при новой игре)
    public static void reset() {
        hasKey = false;
        collectedArtifacts = 0;
        for (int i = 0; i < levelsCompleted.length; i++) {
            levelsCompleted[i] = false;
        }
    }

    // Отметить уровень как пройденный
    public static void completeLevel(int levelIndex) {
        if (levelIndex >= 1 && levelIndex <= 20) {
            levelsCompleted[levelIndex - 1] = true;
        }
    }
}