import greenfoot.*;

public class spike extends Actor {
    public spike() {
        setImage("spike.png"); // 24x24
    }

    public void act() {
        // Убить героя
        if (isTouching(hero.class)) {
            // Перезапустить текущий уровень
            World world = getWorld();
            if (world instanceof Level1) Greenfoot.setWorld(new Level1());
            else if (world instanceof Level2) Greenfoot.setWorld(new Level2());
            else if (world instanceof Level3) Greenfoot.setWorld(new Level3());
            else if (world instanceof Level4) Greenfoot.setWorld(new Level4());
            else if (world instanceof Level5) Greenfoot.setWorld(new Level5());
            else if (world instanceof Level6) Greenfoot.setWorld(new Level6());
            else if (world instanceof Level7) Greenfoot.setWorld(new Level7());
            else if (world instanceof Level8) Greenfoot.setWorld(new Level8());
            else if (world instanceof Level9) Greenfoot.setWorld(new Level9());
            else if (world instanceof Level10) Greenfoot.setWorld(new Level10());
            else if (world instanceof Level11) Greenfoot.setWorld(new Level11());
            else if (world instanceof Level12) Greenfoot.setWorld(new Level12());
            else if (world instanceof Level13) Greenfoot.setWorld(new Level13());
            else if (world instanceof Level14) Greenfoot.setWorld(new Level14());
            else if (world instanceof Level15) Greenfoot.setWorld(new Level15());
            else if (world instanceof Level16) Greenfoot.setWorld(new Level16());
            else if (world instanceof Level17) Greenfoot.setWorld(new Level17());
            else if (world instanceof Level18) Greenfoot.setWorld(new Level18());
            else if (world instanceof Level19) Greenfoot.setWorld(new Level19());
            else if (world instanceof Level20) Greenfoot.setWorld(new Level20());
            return;
        }

        // Разрушить ящик
        if (isTouching(box.class)) {
            box b = (box) getOneObjectAtOffset(0, 0, box.class);
            if (b != null) {
                getWorld().removeObject(b);
                getWorld().addObject(new GameMessage("Ящик разрушен!"), 400, 50);
            }
        }
    }
}