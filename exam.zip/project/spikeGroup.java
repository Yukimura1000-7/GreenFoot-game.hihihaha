// spikeGroup.java
import greenfoot.*;
import java.util.*;

public class spikeGroup extends Actor {
    private List<spike> spikes = new ArrayList<>();
    private boolean active = true;

    public spikeGroup() {
        setImage(new GreenfootImage(1, 1)); // невидимый актёр-контроллер
    }

    public void act() {
        // Ничего не делаем — управление через внешний вызов
    }

    public void activate() {
        if (!active) {
            for (spike s : spikes) {
                getWorld().addObject(s, s.getX(), s.getY());
            }
            active = true;
        }
    }

    public void deactivate() {
        if (active) {
            for (spike s : spikes) {
                if (s.getWorld() != null) {
                    getWorld().removeObject(s);
                }
            }
            active = false;
        }
    }

    public void addSpike(spike s) {
        spikes.add(s);
    }

    public boolean isActive() {
        return active;
    }
}