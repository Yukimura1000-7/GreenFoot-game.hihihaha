import greenfoot.*;

public class mentor extends Actor {
    public mentor() {
        setImage("mentor.png"); 
    }
}