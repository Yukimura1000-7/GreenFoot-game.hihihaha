import greenfoot.*;

public class clevel4 extends Actor
{
    private GreenfootImage clevel4;
    public clevel4(){
        clevel4 = new GreenfootImage("clevel4.png");
        setImage(clevel4);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
