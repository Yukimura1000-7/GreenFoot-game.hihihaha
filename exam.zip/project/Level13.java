import greenfoot.*;

public class Level13 extends World {
    public Level13() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(0, 100, 150));
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new mirror(), 400, 300);
        //addObject(new pressurePlate(), 600, 300);
        addObject(new key(), 500, 200);
        addObject(new door(14), 700, 200);

        addObject(new torch(), 50, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level13());
        }
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}