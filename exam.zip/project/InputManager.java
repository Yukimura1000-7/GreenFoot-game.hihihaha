import greenfoot.*; 

public class InputManager {
    private static boolean rWasPressed = false;

    public static boolean isKeyPressed(String key) {
        boolean isDown = Greenfoot.isKeyDown(key); // теперь работает
        if (isDown && !rWasPressed) {
            rWasPressed = true;
            return true;
        } else if (!isDown) {
            rWasPressed = false;
        }
        return false;
    }
}