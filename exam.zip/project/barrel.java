import greenfoot.*;

public class barrel extends Actor {
    public barrel() {
        setImage("barrel.png"); 
    }
}