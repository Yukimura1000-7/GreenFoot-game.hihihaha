import greenfoot.*;

public class clevel16 extends Actor
{
    private GreenfootImage clevel16;
    public clevel16(){
        clevel16 = new GreenfootImage("clevel16.png");
        setImage(clevel16);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}

