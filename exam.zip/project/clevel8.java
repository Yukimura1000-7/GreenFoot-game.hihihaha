import greenfoot.*;

public class clevel8 extends Actor
{
    private GreenfootImage clevel8;
    public clevel8(){
        clevel8 = new GreenfootImage("clevel8.png");
        setImage(clevel8);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
