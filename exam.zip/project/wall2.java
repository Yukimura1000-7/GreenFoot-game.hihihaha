import greenfoot.*;

public class wall2 extends Actor {
    public wall2() {
        setImage("wall2.png"); 
    }
}