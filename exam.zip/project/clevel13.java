import greenfoot.*;

public class clevel13 extends Actor
{
    private GreenfootImage clevel13;
    public clevel13(){
        clevel13 = new GreenfootImage("clevel13.png");
        setImage(clevel13);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}

