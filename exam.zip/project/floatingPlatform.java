import greenfoot.*;

public class floatingPlatform extends Actor {
    private int timer = 0;
    private boolean activated = false;
    private static final int DURATION = 120;

    public floatingPlatform() {
        setImage("platform.png"); 
    }

    public void act() {
        if (!activated) {
            if (isTouching(hero.class)) {
                activated = true;
                timer = DURATION;
            }
        } else {
            timer--;
            if (timer <= 0) {
                getWorld().removeObject(this);
            }
        }
    }
}