import greenfoot.*;

public class LevelSelection extends World {
    private static final int COLUMNS = 5;
    private static final int ROWS = 4;
    private static final int ICON_WIDTH = 170;
    private static final int ICON_HEIGHT = 100;
    private static final int START_X = 80;
    private static final int START_Y = 60;

    public LevelSelection() {    
        super(840, 500, 1); 
        setBackground("background.png");

        addObject(new backtomain(), 100, 450);

        Actor[] levelIcons = {
            new clevel1(),
            new clevel2(),
            new clevel3(),
            new clevel4(),
            new clevel5(),
            new clevel6(),
            new clevel7(),
            new clevel8(),
            new clevel9(),
            new clevel10(),
            new clevel11(),
            new clevel12(),
            new clevel13(),
            new clevel14(),
            new clevel15(),
            new clevel16(),
            new clevel17(),
            new clevel18(),
            new clevel19(),
            new clevel20()
        };

        for (int i = 0; i < levelIcons.length; i++) {
            int row = i / COLUMNS;           
            int col = i % COLUMNS;           
            int x = START_X + col * ICON_WIDTH;
            int y = START_Y + row * ICON_HEIGHT;
            addObject(levelIcons[i], x, y);
        }
    }
}