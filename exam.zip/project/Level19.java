import greenfoot.*;

public class Level19 extends World {
    public Level19() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(160, 0, 160));
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new lever(), 300, 400);
        addObject(new mirror(), 400, 400);
        addObject(new key(), 500, 300);
        addObject(new door(20), 700, 300);

        addObject(new barrel(), 200, 400);
        addObject(new torch(), 50, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level19());
        }
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}