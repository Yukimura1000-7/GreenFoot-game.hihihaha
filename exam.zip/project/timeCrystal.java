import greenfoot.*;

public class timeCrystal extends Actor {
    private boolean isActive = false;
    private int cooldown = 0;
    private static final int COOLDOWN_FRAMES = 180;

    public timeCrystal() {
        setImage("crystal_inactive.png"); 
    }

    public void act() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (isTouching(hero.class) && Greenfoot.isKeyDown("t")) {
            isActive = !isActive;
            updateImage();
            String msg = isActive ? "Кристалл активирован!" : "Время восстановлено.";
            getWorld().addObject(new GameMessage(msg), 400, 50);
            cooldown = COOLDOWN_FRAMES;
        }
    }

    private void updateImage() {
        if (isActive) {
            setImage("crystal_active.png"); 
        } else {
            setImage("crystal_inactive.png"); 
        }
    }
}