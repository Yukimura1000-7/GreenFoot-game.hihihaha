public class SpikeData {
    public int x, y;
    public spike spike;

    public SpikeData(spike s, int x, int y) {
        this.spike = s;
        this.x = x;
        this.y = y;
    }
}