import greenfoot.*;

public class clevel7 extends Actor
{
    private GreenfootImage clevel7;
    public clevel7(){
        clevel7 = new GreenfootImage("clevel7.png");
        setImage(clevel7);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}

