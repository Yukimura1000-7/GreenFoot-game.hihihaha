import greenfoot.*;

public class clevel15 extends Actor
{
    private GreenfootImage clevel15;
    public clevel15(){
        clevel15 = new GreenfootImage("clevel15.png");
        setImage(clevel15);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
