import greenfoot.*;

public class Level9 extends World {
    public Level9() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.GREEN);
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new guardian(), 400, 300);
        addObject(new key(), 450, 250);
        addObject(new door(10), 700, 250);

        addObject(new barrel(), 200, 400);
        addObject(new bush(), 600, 200);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level9());
        }
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}