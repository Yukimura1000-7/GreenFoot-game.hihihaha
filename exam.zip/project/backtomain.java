import greenfoot.*;

public class backtomain extends Actor {
    public backtomain() {
        setImage("backtomain.png"); 
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new main_menu());
        }
    }
}