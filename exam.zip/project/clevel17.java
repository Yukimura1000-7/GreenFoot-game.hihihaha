import greenfoot.*;

public class clevel17 extends Actor
{
    private GreenfootImage clevel17;
    public clevel17(){
        clevel17 = new GreenfootImage("clevel17.png");
        setImage(clevel17);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
