import greenfoot.*;
import java.util.*;

public class pressurePlate extends Actor {
    private List<SpikeData> spikes;
    private boolean isActive = false;

    public pressurePlate(List<SpikeData> spikes) {
        this.spikes = spikes;
        setImage("plate.png");
    }

    public void act() {
        boolean pressed = isTouching(box.class) || isTouching(hero.class);
        if (pressed != isActive) {
            isActive = pressed;
            if (isActive) {
                // Убираем шипы
                for (SpikeData sd : spikes) {
                    if (sd.spike.getWorld() != null) {
                        getWorld().removeObject(sd.spike);
                    }
                }
                getWorld().addObject(new GameMessage("Проход открыт!"), 400, 50);
            } else {
                // Восстанавливаем шипы
                for (SpikeData sd : spikes) {
                    if (sd.spike.getWorld() == null) {
                        getWorld().addObject(sd.spike, sd.x, sd.y);
                    }
                }
                getWorld().addObject(new GameMessage("Проход закрыт."), 400, 50);
            }
        }
    }
}