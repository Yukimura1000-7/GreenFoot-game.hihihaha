import greenfoot.*;

// Экран победы после прохождения Level20
public class VictoryScreen extends World {
    public VictoryScreen() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.DARK_GRAY);
        bg.fill();
        setBackground(bg);
        showText("Поздравляем!", 400, 250);
        showText("Ты прошёл «Последний Урок».", 400, 300);
        showText("Нажми R, чтобы вернуться в меню.", 400, 350);
    }

    public void act() {
        if (Greenfoot.isKeyDown("r")) {
            Greenfoot.setWorld(new main_menu());
        }
    }
}