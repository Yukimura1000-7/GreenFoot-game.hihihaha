import greenfoot.*;

public class clevel9 extends Actor
{
    private GreenfootImage clevel9;
    public clevel9(){
        clevel9 = new GreenfootImage("clevel9.png");
        setImage(clevel9);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}

