import greenfoot.*;

public class key extends Actor {
    public key() {
        setImage("key.png");
    }
}