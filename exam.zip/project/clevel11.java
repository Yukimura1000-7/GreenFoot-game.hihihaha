import greenfoot.*;

public class clevel11 extends Actor
{
    private GreenfootImage clevel11;
    public clevel11(){
        clevel11 = new GreenfootImage("clevel11.png");
        setImage(clevel11);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}
