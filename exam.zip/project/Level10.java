import greenfoot.*;

public class Level10 extends World {
    public Level10() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.CYAN);
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new floatingPlatform(), 250, 450);
        addObject(new floatingPlatform(), 350, 400);
        addObject(new key(), 500, 300);
        addObject(new door(11), 700, 300);
        addObject(new barrel(), 100, 450);
        addObject(new torch(), 700, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level10());
        }
        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}