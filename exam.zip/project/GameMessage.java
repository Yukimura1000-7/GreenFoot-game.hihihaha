import greenfoot.*;

public class GameMessage extends Actor {
    private int lifetime = 120;

    public GameMessage(String text) {
        GreenfootImage img = new GreenfootImage(200, 30);
        img.setColor(Color.BLACK);
        img.fill();
        img.setColor(Color.WHITE);
        img.drawString(text, 10, 20);
        setImage(img);
    }

    public void act() {
        lifetime--;
        if (lifetime <= 0) {
            getWorld().removeObject(this);
        }
    }
}