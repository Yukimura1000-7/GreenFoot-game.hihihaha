import greenfoot.*;

public class guardian extends Actor {
    private boolean isAwake = false;
    private int moveDirection = 1;
    private int moveTimer = 0;

    public guardian() {
        setImage("guardian.png"); 
    }

    public void act() {
        if (!isAwake) {
            if (isTouching(hero.class)) {
                isAwake = true;
            }
        } else {
            moveTimer++;
            if (moveTimer % 60 == 0) {
                moveDirection *= -1;
            }
            setLocation(getX() + moveDirection, getY());
        }
    }
}