import greenfoot.*;

public class bush extends Actor {
    public bush() {
        setImage("bush.png"); 
    }
}