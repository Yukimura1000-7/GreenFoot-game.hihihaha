import greenfoot.*;

public class wall extends Actor {
    public wall() {
        setImage("wall.png"); 
    }
}