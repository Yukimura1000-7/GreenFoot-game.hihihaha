import greenfoot.*;

public class clevel2 extends Actor
{
    private GreenfootImage clevel2;
    public clevel2(){
        clevel2 = new GreenfootImage("clevel2.png");
        setImage(clevel2);
    }
    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            getWorld().addObject(
                new GameMessage("В следующем обновлении!"), 450,50);
        }
    }
}

