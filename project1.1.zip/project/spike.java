import greenfoot.*;

public class spike extends Actor {
    public spike() {
        setImage("spike.png"); 
    }

    public void act() {
        if (isTouching(box.class)) {
            box b = (box) getOneObjectAtOffset(0, 0, box.class);
            if (b != null) {
                getWorld().removeObject(b);
                getWorld().addObject(new GameMessage("Ящик разрушен!"), 400, 50);
            }
        }
    }
}