import greenfoot.*;

public class Level6 extends World {
    public Level6() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.GREEN);
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new floatingPlatform(), 250, 450);
        addObject(new floatingPlatform(), 350, 400);
        addObject(new key(), 500, 300);
        addObject(new door(7), 700, 300);
        addObject(new bush(), 700, 500);
        addObject(new torch(), 50, 550);

        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}