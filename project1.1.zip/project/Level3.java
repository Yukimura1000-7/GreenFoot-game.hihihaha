import greenfoot.*;

public class Level3 extends World {
    public Level3() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.BLUE);
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new mentor(), 500, 300);
        addObject(new pressurePlate(), 500, 300);
        addObject(new key(), 300, 200);
        addObject(new door(4), 700, 200);

        addObject(new barrel(), 200, 400);
        addObject(new torch(), 600, 550);

        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
            addObject(new wall(), x, 20);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}