import greenfoot.*;

public class Level20 extends World {
    public Level20() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(180, 0, 180));
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new mentor(), 400, 300);
        addObject(new pressurePlate(), 400, 300);
        addObject(new barrel(), 200, 400);
        addObject(new torch(), 50, 550);

        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}