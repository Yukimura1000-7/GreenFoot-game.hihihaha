import greenfoot.*;

public class Level17 extends World {
    public Level17() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(120, 0, 120));
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new floatingPlatform(), 200, 400);
        addObject(new floatingPlatform(), 300, 300);
        addObject(new key(), 400, 200);
        addObject(new door(18), 700, 200);

        addObject(new barrel(), 150, 450);
        addObject(new torch(), 50, 550);

        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}