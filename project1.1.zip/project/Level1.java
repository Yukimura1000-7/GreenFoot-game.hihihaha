import greenfoot.*;

public class Level1 extends World {
    public Level1() {
        super(800, 600, 1);
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(Color.DARK_GRAY);
        bg.fill();
        setBackground(bg);

        addObject(new hero(), 100, 500);
        addObject(new box(), 300, 500);
        addObject(new key(), 500, 300);
        addObject(new door(2), 700, 300);

        addObject(new spike(), 400, 500);
        addObject(new spike(), 424, 500);

        for (int x = 300; x <= 550; x += 24) {
            addObject(new wall(), x, 350);
        }

        addObject(new barrel(), 150, 450);
        addObject(new torch(), 50, 550);

        borderWalls();
    }

    private void borderWalls() {
        for (int x = 0; x < 800; x += 24) {
            addObject(new wall(), x, 580);
            addObject(new wall(), x, 20);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new wall(), 20, y);
            addObject(new wall(), 780, y);
        }
    }
}