import greenfoot.*;

public class mentor extends Actor {
    private final int speed = 1;

    public mentor() {
        setImage("mentor.png");
    }

    public void act() {
        if (Level1.activePlayer != this) return;
        handleMovement();
        // НЕТ handleInteraction() — ментор ничего не трогает!
    }

    private void handleMovement() {
        int prevX = getX();
        int prevY = getY();

        if (Greenfoot.isKeyDown("left")) setLocation(getX() - speed, getY());
        if (Greenfoot.isKeyDown("right")) setLocation(getX() + speed, getY());
        if (Greenfoot.isKeyDown("up")) setLocation(getX(), getY() - speed);
        if (Greenfoot.isKeyDown("down")) setLocation(getX(), getY() + speed);

        if (isTouching(InvisibleWall.class) || 
            isTouching(barrel.class) || 
            isTouching(bush.class) || 
            isTouching(torch.class) ||
            isTouching(wall.class) ||
            isTouching(wall2.class)) {
            setLocation(prevX, prevY);
        }
    }
}