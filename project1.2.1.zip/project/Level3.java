import greenfoot.*;

public class Level3 extends World {
    public Level3() {
        super(800, 600, 1);
        setBackground("backlevel1.png");

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        addObject(new mentor(), 500, 300);
        //addObject(new pressurePlate(), 500, 300);
        addObject(new key(), 300, 200);
        addObject(new door(4), 700, 200);

        addObject(new barrel(), 200, 400);
        addObject(new torch(), 600, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level3());
        }
    }
}