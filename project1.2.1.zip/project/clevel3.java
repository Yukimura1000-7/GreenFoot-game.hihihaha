import greenfoot.*;

public class clevel3 extends Actor
{
    private GreenfootImage clevel3;
    public clevel3(){
        clevel3 = new GreenfootImage("clevel3.png");
        setImage(clevel3);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new Level3()); 
        }
    }
}

