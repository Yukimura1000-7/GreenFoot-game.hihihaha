import greenfoot.*;

public class ResumeButton extends Actor {
    public ResumeButton() {
        setImage("resume_button.png"); // или текст через GreenfootImage
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            World world = getWorld();
            world.removeObject(world.getObjects(PauseMenu.class).get(0));
            world.removeObject(this);
            world.removeObject(world.getObjects(SettingsButton.class).get(0));
            world.removeObject(world.getObjects(ExitToMenuButton.class).get(0));
        }
    }
}