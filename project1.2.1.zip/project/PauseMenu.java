import greenfoot.*;

public class PauseMenu extends Actor {
    public PauseMenu() {
        GreenfootImage img = new GreenfootImage(300, 200);
        img.setColor(new Color(0, 0, 0, 180));
        img.fill();
        setImage(img);
    }
}