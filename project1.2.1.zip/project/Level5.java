import greenfoot.*;

public class Level5 extends World {
    public Level5() {
        super(800, 600, 1);
        setBackground("backlevel1.png");

        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        //addObject(new pressurePlate(), 150, 550);
        addObject(new mentor(), 400, 300);
        //addObject(new pressurePlate(), 400, 300);
        addObject(new lever(), 600, 400);
        addObject(new key(), 300, 200);
        addObject(new door(6), 700, 200);

        addObject(new barrel(), 200, 400);
        addObject(new torch(), 600, 550);

        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level5());
        }
    }
}