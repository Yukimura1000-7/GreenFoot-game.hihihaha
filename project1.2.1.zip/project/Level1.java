import greenfoot.*;
import java.util.*;

public class Level1 extends World {
    private List<SpikeData> spikes = new ArrayList<>();
    private boolean isPaused = false;
    public static Actor activePlayer = null;

    public Level1() {
        super(800, 600, 1);
        setBackground("backlevel1.png");

        hero h = new hero();
        mentor m = new mentor();
        
        addObject(h, 100, 500);
        addObject(m, 150, 500);
        addObject(new box(), 650, 150); 
        addObject(new key(), 500, 250);
        addObject(new door(2), 690, 250);

        activePlayer = h;
        
        addObject(new wall(), 430, 325);

        
        for (int y = 20; y <= 320; y += 30) {
            addObject(new wall2(), 600, y);
        }

        // Декор
        addObject(new barrel(), 100, 250);
        addObject(new torch(), 300, 320);

        spikes.add(new SpikeData(new spike(), 250, 310));
        spikes.add(new SpikeData(new spike(), 225, 310));
        spikes.add(new SpikeData(new spike(), 200, 310));
        spikes.add(new SpikeData(new spike(), 175, 310));
        spikes.add(new SpikeData(new spike(), 150, 310));
        spikes.add(new SpikeData(new spike(), 125, 310));
        spikes.add(new SpikeData(new spike(), 100, 310));
        for (SpikeData sd : spikes) {
            addObject(sd.spike, sd.x, sd.y);
        }
        
        pressurePlate plate = new pressurePlate(spikes);
        addObject(plate, 400, 550);

        for (int x = 0; x < 800; x += 24) {
            addObject(new InvisibleWall(), x, 0);
            addObject(new InvisibleWall(), x, 568);
        }
        for (int y = 0; y < 600; y += 32) {
            addObject(new InvisibleWall(), 80, y);  
            addObject(new InvisibleWall(), 730, y); 
        }
    }
    public void act() {
        if (Greenfoot.isKeyDown("1")) {
            for (Object obj : getObjects(hero.class)) {
                activePlayer = (Actor) obj;
                break;
            }
        } else if (Greenfoot.isKeyDown("2")) {
            for (Object obj : getObjects(mentor.class)) {
                activePlayer = (Actor) obj;
                break;
            }
        }
    }
}
