import greenfoot.*;

public class Level2 extends World {
    public Level2() {
        super(800, 600, 1);
        setBackground("backlevel1.png");
        addObject(new hero(), 100, 500);
        addObject(new box(), 150, 500);
        //addObject(new pressurePlate(), 150, 550);
        addObject(new key(), 500, 300);
        addObject(new door(3), 700, 300);
        addObject(new barrel(), 200, 400);
        addObject(new torch(), 600, 550);
        
        if (Greenfoot.isKeyDown("r")) {
        Greenfoot.setWorld(new Level2());
        }
    }   
}