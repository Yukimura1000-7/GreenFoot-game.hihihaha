public class GameState {
    public static boolean hasKey = false;
    
    public static boolean[] levelsCompleted = new boolean[20];

    public static void reset() {
        hasKey = false;
        for (int i = 0; i < levelsCompleted.length; i++) {
            levelsCompleted[i] = false;
        }
    }

    public static void completeLevel(int levelIndex) {
        if (levelIndex >= 1 && levelIndex <= 20) {
            levelsCompleted[levelIndex - 1] = true;
        }
    }
}